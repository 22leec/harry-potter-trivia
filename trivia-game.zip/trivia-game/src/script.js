//Runs once at the beginning
function setup() {
  var googleSheetLink = "1yFpvoxaGKiHzbdvnQX3Q_NFpFsBCVJPjstByXam19Is";
  trivia.loadGoogleSheet(googleSheetLink).then(displayWelcome);  
 trivia.categoriesEnabled = true;
}

//Loops continously for background effects and animations. (p5.js)
function draw() {
  if (trivia.state == "welcome") background("pink");
  else if (trivia.state == "categories") background("midnightblue");
  else if (trivia.state == "question") background("lightblue");
  else if (trivia.state == "correct") background("lightgreen");
  else if (trivia.state == "incorrect") background("salmon");
  else if (trivia.state == "thankyou") background("plum");
}

function displayWelcome() {
  $(".screen").hide();
  $("#welcome-screen").show();
  $("#question-count").html(`You have ${trivia.totalQuestions} questions waiting for you.`);
}

function displayCategories() {
  $(".screen").hide();
  $("#category-screen").show();
  trivia.insertCategoriesInfo();
}

function displayQuestion() {
  $(".screen").hide();
  $("#question-screen").show();
  $("#correctAnswer").removeClass("highlight");
  $("#feedback").hide();
  trivia.insertQuestionInfo();
  trivia.shuffleAnswers();
  var timeLimit = 10;
  var startTime = Date.now();
  clearInterval(trivia.countDown);
  trivia.countDown = setInterval(function () {
    if (trivia.state == "question") { 
      var elapsedTime = (Date.now() - startTime)/1000; 
      var clock = timeLimit - Math.floor(elapsedTime);
    $('#timer').html(clock);
      if (clock == 0) { 
      clearInterval(trivia.countDown);
      trivia.triggerAnswer(false);
    }
  }
  else clearInterval(trivia.countDown);
}, 100);//100 is the time interval in milliseconds
}

function displayThankyou() {
  $(".screen").hide();
  $("#thankyou-screen").show();
  $("#game-results").html(`You got ${trivia.totalCorrect} of ${trivia.totalAnswered} correct.`);
}

function onClickedAnswer(isCorrect) {
  $('#score').html(`${trivia.totalCorrect} of ${trivia.totalAnswered} Correct`);
   if (isCorrect) {
    $("#feedback").html(`Way to go!`).show();
    playFile('https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/success.mp3');
  }
  else {
    $("#feedback").html(`Better luck next time.`).show();
    playFile('https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/error.mp3');
  }
  $("#correctAnswer").addClass("highlight"); 
  //setTimeout(trivia.gotoNextQuestion, 1000);
  //button to go to next question
  $("#feedback").append(`<br><button onclick="trivia.gotoNextQuestion();">Next Question</br>`);
}

function onClickedStart() {
  displayCategories();
}

function onClickedCategory() {
  displayQuestion();
}



const context = new window.AudioContext();

function playFile(filepath) {
  fetch(filepath)
    .then(response => response.arrayBuffer())
    .then(arrayBuffer => context.decodeAudioData(arrayBuffer))
    .then(audioBuffer => {
      const soundSource = context.createBufferSource();
      soundSource.buffer = audioBuffer;
      soundSource.connect(context.destination);
      soundSource.start();
    });
}

let successButton = document.querySelector("#success");
successButton.addEventListener("click", function() {
  playFile('https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/success.mp3');
});

let errorButton = document.querySelector("#error");
errorButton.addEventListener("click", function() {
  playFile('https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/error.mp3');
});
